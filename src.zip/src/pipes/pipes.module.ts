import { NgModule } from '@angular/core';
//import { FilterPipe } from './filter/filter';
@NgModule({
	//declarations: [FilterPipe],
	imports: [],
	//exports: [FilterPipe]
})
export class PipesModule {}
