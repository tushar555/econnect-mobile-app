export interface monthYearDetails{
    tokenId:number;
    month:number;
    year:number;
}

export interface userCredentials{
    username: string;
    password: string
}