import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Form16Page } from './form16';

@NgModule({
  declarations: [
    Form16Page,
  ],
  imports: [
    IonicPageModule.forChild(Form16Page),
  ],
})
export class Form16PageModule {}
