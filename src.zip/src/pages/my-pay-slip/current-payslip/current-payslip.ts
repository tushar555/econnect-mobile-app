import { Component, NgZone } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, LoadingController, AlertController, ToastController } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';
import { HttpClient } from '@angular/common/http';
import { PostService } from '../../../providers/api/PostService'
import { Storage } from '@ionic/storage';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { FileTransfer } from '@ionic-native/file-transfer';
/*

install File, File Opener plugin and for pdf PDFMake library using npm
 */
@Pipe({ name: 'inrFormat' })
export class NewPipe implements PipeTransform {
  transform(value: any) {
    if (!value) return 0;
    else return value.toLocaleString();
    //else return value.toLocaleString("hi-IN");
  }
}
@IonicPage()
@Component({
  selector: 'page-current-payslip',
  templateUrl: 'current-payslip.html',
})
export class CurrentPayslipPage {
  companyName: any;
  designation: any;
  pdfSrc: string;
  value3: any[];

  paymentData: any = [];

  pdfObj = null;
  loading: any;
  link: any;
  date = new Date();
  monthsArray: Array<any> = [];
  yearsArray = [];
  year: any;
  month: any;
  totalEarnings: number = 0;
  totalDeductions: number = 0;
  name: any;
  location: any;
  userToken: any;
  total: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, private _plt: Platform,
    public file: File, public fileOpener: FileOpener, public loadingCtrl: LoadingController
    , public alertCtrl: AlertController, public toastCtrl: ToastController, public platform: Platform,
    public zone: NgZone, public http: HttpClient, public postService: PostService, public sanitize: DomSanitizer,
    private _storage: Storage, private locationAccuracy: LocationAccuracy,
    public transfer: FileTransfer) {
    this.postService.getUserDetails().then((userToken) => {
      this.companyName = userToken['companyName'];
      // alert("compan:"+this.companyName);
    });
  }




  initializeMonths() {
    this.monthsArray = ['January', 'February', 'March', 'April',
      'May', 'June', 'July', 'August', 'September',
      'October', 'November', 'December']

  }

  onChange(event) {
    if (event === this.date.getFullYear()) {
      let month = [];
      for (let i = 0; i <= this.date.getMonth(); i++) {
        month.push(this.monthsArray[i]);
      }
      this.monthsArray = month;
    } else {
      this.initializeMonths();
    }

  }

  ionViewDidLoad() {
    this.postService.presentLoadingDefault();
    this.postService.getCurrentTime().then((newDate: any) => {
      this.postService.getUserDetails().then((data: any) => {
        this.date = new Date(newDate);
        this.year = this.date.getFullYear();
        this.month = this.date.getMonth();


        this.name = data.userName;
        this.location = data.userLocation;
        this.userToken = data.tokenid;
        this.designation = data.JobTitle;
       
        for (let i = 0; i <= 2; i++) {
          this.yearsArray.push(this.date.getFullYear() - i);
        }
        this.postService.loading.dismiss();

        this.initializeMonths();
        this.onChange(this.date.getFullYear());
      })

    }).catch((error) => {
      this.postService.loading.dismiss();
      this.navCtrl.pop();
      this.postService.presentToast(error);
    });

  }

  // Create Pdf File object


  // Download function to Preview and Download Pdf
  downloadPdf(month) {
    this.postService.presentLoadingDefault();
    this.postService.getUserDetails().then((user: any) => {

      let data = { 'tokenId': user.tokenid, 'year': this.year, 'month': this.monthsArray.indexOf(month) + 1 };


      // let data = {
      //   "tokenid": "23061537",
      //   "month": 5,
      //   "year": 2018

      // }
      this.postService.getData('SalaryCard/getSalarySlip', data).then((respdata: any) => {


        if (respdata.Message === 'Success') {
          let path = null;

          // if (this.platform.is('ios')) {
          //   path = this.file.documentsDirectory;
          // } else if (this.platform.is('android')) {
          //   path = this.file.dataDirectory;
          // }
          // console.log('path', path);
          // debugger;
          // const transfer = this.transfer.create();
          // console.log('transfer', transfer);
          // let pdfURL = data.SalarySlipPDF;
          // console.log('PDF', pdfURL);

          // transfer.download(pdfURL, path + 'myfile.pdf').then(entry => {
          //   let url = entry.toURL();
          //   this.postService.loading.dismiss();

          //   this.fileOpener.open(url, 'application/pdf');
          //   // this.document.viewDocument(url, 'application/pdf', {});
          // }).catch((error) => {
          //   console.log('Error', error);

          // });

          console.log('Log', respdata.Base64File);
          var binaryString = window.atob(respdata.Base64File);
          var binaryLen = binaryString.length;
          var bytes = new Uint8Array(binaryLen);
          for (var i = 0; i < binaryLen; i++) {
            var ascii = binaryString.charCodeAt(i);
            bytes[i] = ascii;
          }

          let blob = new Blob([bytes], { type: 'application/pdf' });

          let fileName = respdata.FileName === undefined ? 'Mypayslip.pdf' : respdata.FileName
          this.file.writeFile(this.file.dataDirectory, fileName, blob, { replace: true }).then(fileEntry => {
            //   // Open the PDf
            this.fileOpener.open(this.file.dataDirectory + fileName, 'application/pdf');
            //  this.fileOpener.open(data.Base64File, 'application/pdf');
            this.postService.loading.dismiss();
          }).catch((error) => {
            console.log('Error', error);
            this.postService.presentToast("Something went wrong!");
            this.postService.loading.dismiss();
          });
        } else {
          this.postService.loading.dismiss();
          this.postService.presentToast("Sorry Data is Not Present!");
        }
      }).catch((error) => {
        this.postService.loading.dismiss();
        this.postService.presentToast(error);
      });
    })
  }

  downloadPdf2(month) {
    this.postService.presentLoadingDefault();
    this.postService.getUserDetails().then((user: any) => {
      let data = { 'tokenId': user.tokenid, 'year': this.year, 'month': this.monthsArray.indexOf(month) + 1 };
      this.postService.getData('SalaryCard/getSalarySlip', data).then((respdata: any) => {
        if (respdata.Message === 'Success' || respdata.Message === null) {
          this.postService.loading.dismiss();
          if(respdata.data.length>0){
            this.postService.loading.dismiss();
            this.navCtrl.push("PaySlipDocumentsPage", { 'data': respdata.data });
          }else{
           // this.postService.loading.dismiss();
            this.postService.presentToast("No payslip available for this month.");
          }
        } else {
          this.postService.loading.dismiss();
          this.postService.presentToast("Sorry Data is Not Present!");
        }
      }).catch((error) => {
        this.postService.loading.dismiss();
        this.postService.presentToast(error);
      });
    })
  }
}