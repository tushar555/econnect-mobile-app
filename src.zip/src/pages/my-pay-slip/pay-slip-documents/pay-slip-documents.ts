import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PostService } from '../../../providers/api/PostService';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';
import { Platform } from 'ionic-angular'; 
/**
 * Generated class for the PaySlipDocumentsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-pay-slip-documents',
  templateUrl: 'pay-slip-documents.html',
})
export class PaySlipDocumentsPage {
  companyName: string;
  documents: {}[] = [];

  constructor(public platform:Platform ,public navCtrl: NavController, public navParams: NavParams, public postService: PostService, 
    public file: File, public fileOpener: FileOpener,) {
    this.postService.getUserDetails().then((userToken) => {
      this.companyName = userToken['companyName'];
      this.documents = this.navParams.get('data');
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PaySlipDocumentsPage');
  }

  showFile(filedata){
    let fileName = filedata.FileName === undefined ? 'Mypayslip.pdf' : filedata.FileName;
    console.log('fileName', fileName);
    const writeDirectory = this.platform.is('ios') ? this.file.dataDirectory : this.file.externalDataDirectory;
    console.log('WRITE', writeDirectory);
   this.postService.presentLoadingDefault();
   this.file.writeFile(writeDirectory, fileName, this.convertBase64ToBlob(filedata.Base64File, 'data:application/pdf;base64'), {replace: true})
      .then((data) => {
        console.log('data', data);
          this.postService.loading.dismiss();
          this.fileOpener.open(writeDirectory + fileName, 'application/pdf')
              .catch((err) => {
                  console.log('Error opening pdf file',err);
          //      this.postService.loading.dismiss();
        
              });
      })
      .catch((error) => {
        this.postService.loading.dismiss();
        console.log('Error opening pdf file123',error);
       //   this.postService.loading.dismiss();

      });
  }

  saveAndOpenPdf(pdf: string, filename: string) {
   
  }


  convertBase64ToBlob(b64Data, contentType): Blob {
    contentType = contentType || '';
    const sliceSize = 512;
    b64Data = b64Data.replace(/^[^,]+,/, '');
    b64Data = b64Data.replace(/\s/g, '');
    const byteCharacters = window.atob(b64Data);
    const byteArrays = [];
    for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
         const slice = byteCharacters.slice(offset, offset + sliceSize);
         const byteNumbers = new Array(slice.length);
         for (let i = 0; i < slice.length; i++) {
             byteNumbers[i] = slice.charCodeAt(i);
         }
         const byteArray = new Uint8Array(byteNumbers);
         byteArrays.push(byteArray);
    }
   return new Blob(byteArrays, {type: contentType});
}

  //this.postService.presentLoadingDefault();
  //base 64
// let downloadPDF: any = filedata.Base64File;
// fetch('data:application/pdf;base64,' + downloadPDF,
//   {
//     method: "GET"
//   }).then(res => res.blob()).then(blob => {
//     this.file.writeFile(this.file.externalApplicationStorageDirectory, 'Mypayslip.pdf', blob, { replace: true }).then(res => {
//       this.fileOpener.open(
//         res.toInternalURL(),
//         'application/pdf'
//       ).then((res) => {
//         console.log("dfgfhf")
//       }).catch(err => {
//         console.log("open error")
//       });
//     }).catch(err => {
//           console.log("save error")     
// });
//   }).catch(err => {
//          console.log("error")
//   });

  //  var binaryString = window.atob(filedata.Base64File);
  //  var binaryLen = binaryString.length;
  //  var bytes = new Uint8Array(binaryLen);
  //  console.log(bytes,"bytes..");
  //  for (var i = 0; i < binaryLen; i++) {
  //    var ascii = binaryString.charCodeAt(i);
  //    bytes[i] = ascii;
  //  }
  //  console.log(bytes,"bytes123..");
  //  let blob = new Blob([bytes], { type: 'application/pdf' });
  //  console.log(blob,"blob123..");
  //  let fileName = filedata.FileName === undefined ? 'Mypayslip.pdf' : filedata.FileName;
  //  console.log(fileName,"fileName..");
  //  console.log(this.file.dataDirectory, 'this.file.dataDirectory');
  //  this.file.writeFile(this.file.dataDirectory, fileName, blob, { replace: true }).then(fileEntry => {
  //    //   // Open the PDf
  //    alert(JSON.stringify(fileEntry)+"fileEntry..");
  //    this.postService.dismissLoading();
  //    this.fileOpener.open(this.file.dataDirectory + fileName, 'application/pdf');
  //    console.log(this.file.dataDirectory + fileName,"this.file.dataDirectory + fileName123..");
  //    //  this.fileOpener.open(data.Base64File, 'application/pdf');
  //  }).catch((error) => {
  //    alert('Error'+ JSON.stringify(error));
  //    this.postService.dismissLoading();
  //    this.postService.presentToast("Something went wrong!");
  //  });
}
