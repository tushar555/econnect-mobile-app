import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminEmployeeDetailsPage } from './admin-employee-details';
import { DateTimeFormatPipe } from '../../../pipes/date-time-format/date-time-format';

@NgModule({
  declarations: [
    AdminEmployeeDetailsPage,
    DateTimeFormatPipe
  ],
  imports: [
    IonicPageModule.forChild(AdminEmployeeDetailsPage),
  ]
})
export class AdminEmployeeDetailsPageModule {}
